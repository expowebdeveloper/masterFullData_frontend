import React from 'react'

const Properties = () => {
  return (
    <div>Properties</div>
  )
}

export default Properties