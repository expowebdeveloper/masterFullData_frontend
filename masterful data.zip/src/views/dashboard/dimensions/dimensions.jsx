import React from 'react'

const Dimensions = () => {
  return (
    <div>Dimensions</div>
  )
}

export default Dimensions