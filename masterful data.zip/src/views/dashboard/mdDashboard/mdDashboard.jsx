import React from 'react'

const MdDashboard = () => {
  return (
    <div>MdDashboard</div>
  )
}

export default MdDashboard