import React from 'react'

const PrivateLayout = () => {
  return (
    <div>PrivateLayout</div>
  )
}

export default PrivateLayout